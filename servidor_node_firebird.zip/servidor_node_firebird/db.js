const connection = {
    //host: '127.0.0.1',
    host: '64.227.27.56',
    //port: 3050,
    port: 3050,
    //database: 'C:/DB/CRUD/TASKDB.FDB',
    database: 'reservas',
    user: 'SYSDBA',
    password: 'masterkey6',
    lowercase_keys: false, // set to true to lowercase keys
    role: null,            // default
    pageSize: 8192         // default when creating database
}

module.exports = connection;
