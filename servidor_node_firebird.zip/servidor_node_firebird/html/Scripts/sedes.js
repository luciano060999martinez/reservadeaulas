window.addEventListener('load', function () {
    var urlencoded = new URLSearchParams();

    var requestOptions = {
        method: 'POST',
        body: urlencoded,
        redirect: 'follow'
    };

    fetch("http://64.227.27.56:4000/sedes", requestOptions)
        .then(response => response.json())
        .then(result => {
            const select = document.querySelector("#cbox_sede");

            for (let i = 0; i < result.length; i++) {
                let option = document.createElement('option');
                option.value = result[i]["ID_SEDE"];
                option.text = result[i]["NOMBRE_SEDE"];
                select.appendChild(option);
            }

            var myHeaders = new Headers();
            myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

            var urlencoded = new URLSearchParams();
            urlencoded.append("id_sede", result[0]["ID_SEDE"]);

            var requestOptions1 = {
                method: 'POST',
                headers: myHeaders,
                body: urlencoded,
                redirect: 'follow'
            };

            fetch("http://64.227.27.56:4000/aulas_x_sedes", requestOptions1)
                .then(response => response.json())
                .then(result => {
                    const select = document.querySelector("#cbox_aula");

                    for (let i = 0; i < result.length; i++) {
                        let option = document.createElement('option');
                        option.value = result[i]["ID_AULA"];
                        option.text = result[i]["NOMBRE_AULA"];
                        select.appendChild(option);
                    }
                })
                .catch(error => console.log('error', error));

        })
        .catch(error => console.log('error', error));
})

document.querySelector("#cbox_sede").addEventListener('change', function () {
    $("#cbox_aula").empty();
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    const sedeactual = $(this).val();
    console.log("=> "+sedeactual);
    urlencoded.append("id_sede", sedeactual);

    var requestOptions2 = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    fetch("http://64.227.27.56:4000/aulas_x_sedes", requestOptions2)
        .then(response => response.json())
        .then(result => {
            const select = document.querySelector("#cbox_aula");

            for (let i = 0; i < result.length; i++) {
                let option = document.createElement('option');
                option.value = result[i]["ID_AULA"];
                option.text = result[i]["NOMBRE_AULA"];
                select.appendChild(option);
            }
        })
        .catch(error => console.log('error', error));
})