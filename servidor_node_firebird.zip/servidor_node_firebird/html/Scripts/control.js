window.onload = () => {
    const usuario = localStorage.getItem("id_usuario");
    console.log(usuario);
    console.log('Evento');
    if (usuario == null)
    {
        window.location.href = 'Login.html';
    }
}