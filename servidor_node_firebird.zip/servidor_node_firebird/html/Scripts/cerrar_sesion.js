document.querySelector("#salir").addEventListener('click', function () {
    localStorage.clear();
});