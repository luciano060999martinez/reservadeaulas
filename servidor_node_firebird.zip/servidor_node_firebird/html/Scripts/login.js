
async function log(user, pass) {
  var myHeaders = new Headers();
  myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

  /*let dato1 = user.toString();
  let dato2 = pass.toString();

  console.log(dato1);
  console.log(dato2);*/

  var urlencoded = new URLSearchParams();
  urlencoded.append("email_usuario", user);
  urlencoded.append("contrasena", pass);

  console.log(urlencoded.toString)

  var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: urlencoded,
    redirect: 'follow'
  };

  await fetch("http://64.227.27.56:4000/usuario_login", requestOptions)
    .then((response) => response.text())
    .then(result => {
      console.log(result);
      if (result == '[]') {
        alert('Error al iniciar sesion, vuelva a intentar');
      } else {
        localStorage.setItem("id_usuario", JSON.parse(result)[0]["ID_USUARIO"]);
        //console.log();
        window.location.href = 'Main.html'
      }
    })
    .catch(error => console.log('error', error));
}

document.querySelector('#btn_log').addEventListener('click', async function () {
  const n = document.getElementById("user");//Se obtienen los valores de las cajas de texto
  const m = document.getElementById("pass");

  let user = n.value;
  let pass = m.value;

  //console.log(user + '  ' + pass);

  log(user, pass);


});

window.addEventListener('load', function () {
  localStorage.clear();
});