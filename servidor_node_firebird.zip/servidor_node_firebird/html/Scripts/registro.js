document.querySelector('#btn_registro').addEventListener('click', async function () {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("nombre_usuario", document.getElementById('userNew').value);
    urlencoded.append("email_usuario", document.getElementById('correoElec').value);
    urlencoded.append("telefono_usuario", document.getElementById('telef').value);
    urlencoded.append("contrasena", document.getElementById('passNew').value);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    fetch("http://64.227.27.56:4000/registrar_usuario", requestOptions)
        .then(response => response.text())
        .then(result => alert(result))
        .catch(error => {
            console.log('error', error);
            alert('Error al registrar usuario');
        });
});