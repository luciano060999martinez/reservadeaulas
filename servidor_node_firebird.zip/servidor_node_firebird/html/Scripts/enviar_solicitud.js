document.querySelector('#btn_solicitar').addEventListener('click', function () {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("id_aula", $("#cbox_aula").val());
    urlencoded.append("id_usuario_solicita", localStorage.getItem("id_usuario"));
    urlencoded.append("fecha_deseada", document.getElementById("start").value);
    urlencoded.append("hora_inicio", document.getElementById("hora").value);
    urlencoded.append("hora_fin", document.getElementById("hora2").value);
    urlencoded.append("descripcion_motivo", document.getElementById("texto").value);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
    };

    fetch("http://64.227.27.56:4000/solicitar_reservar", requestOptions)
        .then(response => response.text())
        .then(result => alert(result))
        .catch(error => console.log('error', error));
});