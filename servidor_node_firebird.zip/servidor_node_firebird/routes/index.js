const express = require('express');
const router = express.Router();

const controller = require('../controllers/tasksController');

router.get('/tasks', controller.findAll);
router.get('/task/:id', controller.findOne);
router.post('/tasks', controller.insert);

router.put('/task/:id', controller.update);
router.delete('/task/:id', controller.delete);
//-----------------------------------------------//
//Referentes a las Sedes
router.post('/sedes', controller.sedes);

//Referentes a las Aulas
router.post('/aulas', controller.aulas);
router.post('/aulas_x_sedes', controller.aulas_x_sedes);
//Referentes al Usuario
router.post('/usuario_login', controller.usuario_login);
router.post('/registrar_usuario', controller.registrar_usuario);

//Referentes a la Reserva
router.post('/solicitar_reservar', controller.solicitar_reservar);
//router.get('/estado_solicitud', controller.consultar_estado_solicitud); //Pendiente de Implementar

module.exports = router;