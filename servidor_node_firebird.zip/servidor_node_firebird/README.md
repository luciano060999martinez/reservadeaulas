Leeme:

1)npm i 
(para instalar todas las dependencias)

2)npm start.
